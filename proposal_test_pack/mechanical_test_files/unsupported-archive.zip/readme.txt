This ZIP exists only to test unsupported attachment handling.
